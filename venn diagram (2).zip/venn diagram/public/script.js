var app=angular.module('App', ['ngMaterial','ngAnimate','angular-venn','ngMessages']);
// var app1=angular.module('main'['ui.router'])
// app1.config(function($stateProvider,$urlRouterProvider) {


app.controller('demoController', function($scope,$http) {
	$http.get('./sample.json').success(function(data) {
		// $scope.tooltipFunc = function(branch) {
		// 	return branch.name;
		// };
				// $scope.myStyle="width:150px;height:100px;"
			 $scope.vennData = data.sample;
		 });
		 	$scope.change=function(){
				document.getElementById("change").innerHTML=""
				$http.get('./sam.json').success(function(data) {
					// $scope.tooltipFunc = function(branch) {
					// 	return branch.name;
					// };
							// $scope.myStyle="width:150px;height:100px;"
						 $scope.vennData = data.sample;
					 });
			}
	// console.log("SDLbnkasdkb");
	// $scope.myStyle="width:'200px';background:red";
	// $scope.vennData = [
	// 	{sets: ['Head Count'], size: 70},
	// 	{sets: ['Billable Allocation'], size: 20},
	// 	{sets: ['SGA'], size: 10},
	// 	{sets: ['Non-Billable Allocation'], size: 10},
	// 	 {sets: ['Head Count','Billable Allocation'], size: 20},
	// 	 {sets: ['Head Count','SGA'], size: 30},
	// 	 {sets: ['Head Count','Non-Billable Allocation'], size: 20},
	// 	//  {sets: ['Head Count','Billable Allocation', 'SGA'], size: 1},
	// ];
	// $scope.venn.width

});
